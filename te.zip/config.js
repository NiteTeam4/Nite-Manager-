exports.Prefix = `/`;
exports.Token = ``;
exports.Color = `#000001`;
exports.Port = `8080`;
exports.BotName= `Moderation Bot`;